var pathsuffix = context.getVariable("proxy.url");

print(pathsuffix);

