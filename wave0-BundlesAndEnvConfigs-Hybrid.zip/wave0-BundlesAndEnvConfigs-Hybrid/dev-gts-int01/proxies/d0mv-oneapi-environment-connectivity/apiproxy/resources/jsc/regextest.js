for(var num=1; num<100000; num++){
    var rval=1;
    for (var i = 2; i <= num; i++)
        rval = rval * i;
 }