var org = context.getVariable("urirequest.org");
var vsad = context.getVariable("urirequest.vsad");
var proxyName = context.getVariable("urirequest.proxyname");
var productName = context.getVariable("urirequest.productname");
var pathsuffix = context.getVariable("proxy.pathsuffix");

//print(pathsuffix);

context.setVariable("envPath", '/v1/o/dev2/userroles/' + vsad + '-API-Publisher/permissions');

if (pathsuffix.indexOf('attach-proxy-to-vsad') > -1) {
    
    var permissionData = '{"path":"/applications/' + proxyName + '","permissions":["get","put","delete"]}';
    context.setVariable("request.content", permissionData);
    
    //print('payload set - ' + permissionData);
} else if (pathsuffix.indexOf('attach-product-to-vsad') > -1) {
    var permissionData = '{"organization":"dev2","path":"/apiproducts/' + productName + '","permissions":["delete","get","put"]}';
    context.setVariable("request.content", permissionData);
    
}
