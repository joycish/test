var uriPath = context.getVariable('proxy.pathsuffix');
var reqVerb = context.getVariable('request.verb');

var productPermissions = context.getVariable('verifyapikey.Mgmt-API-Key.apiproduct.PERMISSIONS');
    
var operationAllowed = false;

if (productPermissions) {
    
    print('productPermissions - ' + productPermissions);
    print('reqVerb - ' + reqVerb);
    
    var productPermissionsObj = JSON.parse(productPermissions);
    
    var permissions = productPermissionsObj['resourcePermission'];
    
    permissions.forEach(function(permissionPattern) {
        
        for (var key in permissionPattern) {
          requestVerbsAllowed = permissionPattern[key];
          
          permissionsSplits = key.split('/');
          requestURISplits = uriPath.split('/');
          print("key - " + key)
          print("permissionPattern - " + permissionPattern)
          print("requestVerbsAllowed - " + requestVerbsAllowed)
          print('permissionsSplits - ' + permissionsSplits);
          print('requestURISplits - ' + requestURISplits);
          print('permissionsSplits.length - ' + permissionsSplits.length);
          print('requestURISplits.length - ' + requestURISplits.length);
          
          if (permissionsSplits.length == requestURISplits.length) {
            var i=0;
            permissionsSplits.forEach(function(permissionsSplit) {
    
              if (permissionsSplit == '*') {
              	  permissionsSplits[i] = requestURISplits[i];
              }
              i++;
            });
            
             print('Array.isArray(permissionsSplits) - ' + Array.isArray(permissionsSplits));
              print('Array.isArray(requestURISplits) - ' + Array.isArray(requestURISplits));
               print('permissionsSplits.length - ' + permissionsSplits.length);
                print('requestURISplits.length - ' + requestURISplits.length);
                 print('requestVerbsAllowed.indexOf(reqVerb) - ' + requestVerbsAllowed.indexOf(reqVerb));
                 
            
            
            if (Array.isArray(permissionsSplits) &&
        		Array.isArray(requestURISplits) &&
        		permissionsSplits.length === requestURISplits.length &&
        		permissionsSplits.every((val, index) => val === requestURISplits[index]) &&
                (requestVerbsAllowed.indexOf(reqVerb) > -1)) {
            	
               operationAllowed = true; 
                
            }
          }
        }
    });
}

context.setVariable("operationAllowed", operationAllowed);


