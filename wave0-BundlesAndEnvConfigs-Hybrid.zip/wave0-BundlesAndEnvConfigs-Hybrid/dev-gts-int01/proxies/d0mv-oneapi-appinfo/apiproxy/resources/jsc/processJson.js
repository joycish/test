var value = context.getVariable("appinfo.jsonresult"); 
var jsonresult = value.replace(/\r?\n|\r/g, " ");
context.setVariable("jsonresult", jsonresult);