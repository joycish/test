var value = context.getVariable("system.interface.eth0"); 
context.setVariable("msg_proc_ip", value);