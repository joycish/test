var subjname_header_old = context.getVariable('request.header.X-SUBJECT-NAME');
var subjname_header = context.getVariable('reqst.header.subjectname'); //assigned in the 'Extract SubjectName' policy
var certstatus_header = context.getVariable('request.header.X-CLIENT-CERT-STATUS');
var whitelist = context.getVariable('whitelist');

var domain_name = subjname_header;

print(subjname_header_old);
print(subjname_header);

var logger = "";

if(whitelist !== null && whitelist.trim() !== "") {

    if(certstatus_header !== null) {
    
        if(subjname_header !== null) {
            logger+= subjname_header;
            
            var whitelist_map = whitelist.split(',');
            
            var check = false;
            
            var domain_name_found = whitelist_map.indexOf(domain_name);
            
            if(domain_name_found > -1) {
                domain_name_found = whitelist_map[domain_name_found];
            } else {
                domain_name_found = null;
            }
            
            context.setVariable('logger', logger);
            
            if(domain_name_found !== null) { 
                check = true; 
            
                if(certstatus_header == "ok") {
                	if(check) {
                		context.setVariable('request.header.X-PROPERTY-WHITELIST-VALIDITY', 'TRUE');
                	}
                	else {
                		context.setVariable('request.header.X-PROPERTY-WHITELIST-VALIDITY', 'FALSE');
                		throwErr(401, "User is unauthorized", "Please check your credentials");
                	}
                } else {
                    throwErr(401, "User is unauthorized", "Please check your credentials");
                }
            } else {
                throwErr(401, "User is unauthorized", "Please check your credentials");
            }
        } else {
            throwErr(401, "User is unauthorized", "Please check your credentials");
        }   
    } else {
        throwErr(401, "User is unauthorized", "Please check your credentials");
    }
} else { 
    throwErr(401, "User is unauthorized", "Please check your credentials"); 
}

function throwErr(code, msg, details) {
    
    var errorContent = "";

	var json = {};
	json.Error = {};
	json.Error.Code = code;
	json.Error.Message = msg;
	json.Error.Detail = details;

	errorContent = JSON.stringify(json);
	
	context.setVariable("two-way-ssl-headerchec.failed", "true");
	context.setVariable("two-way-ssl-headerchec.code", code);
	context.setVariable("two-way-ssl-headerchec.message", errorContent);
	
	   
}