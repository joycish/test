// checking trace verb in request
var verb = context.getVariable("request.verb");
//threatValidCheck = "";
if ((verb === "TRACE") || (verb === "TRACK")) 
{
    threatValidCheck = "Failed";
    threatVerbCode = "405";
	context.setVariable( "flow.threatVerbCode", threatVerbCode );
	threatErrorMessage = "Request rejected as unsafe.Please check";
	context.setVariable( "flow.threatErrorMessage", threatErrorMessage );
	//throw new Error("Request verb - "+ verb + " rejected as unsafe.");
}
else
{
    //checking headers and query params 
    var queryParamNames = context.getVariable("request.queryparams.names")+'';
    var headerParamNames = context.getVariable("request.headers.names")+'';
    var formParamNames = context.getVariable("request.formparams.names");
    var hParam=headerParamNames.substring(1, headerParamNames.length-1).split(",");
    var qParam=queryParamNames.substring(1, queryParamNames.length-1).split(",");
    var fParam= null;
    if(formParamNames !== null){
        formParamNames = context.getVariable("request.formparams.names")+'';
        fParam=formParamNames.substring(1, formParamNames.length-1).split(",");
    }
    //var fParam=formParamNames.substring(1, formParamNames.length-1).split(",");
    var array1 = hParam.concat(qParam);
    var array3 = array1.concat(fParam);
    
    var regex = [];
    //regex[0] = RegExp("[\s]*((delete)|(exec)|(drop\s*table)|(script)|(insert)|(shutdown)|(update)|(\bor\b))","i");
    //regex[0] = RegExp("[\\s]*((delete)|(exec)|(drop\\s*table)|(insert)|(shutdown)|(update)|(\\bor\\b))","i");
    regex[0] = RegExp("((\\bdelete\\b)|(\\bexec\\b)|(\\bdrop\\s*table\\b)|(\\binsert\\b)|(\\bshutdown\\b)|(\\bupdate\\b)|(\\bor\\b))","i");
    regex[1] = RegExp("<\\s*script\\b[^>]*>[^<]*<\\s*/\\s*script\\b\\s*>","i");
    var faultVarName = null;
    /*
    array3.forEach(function(paramName) 
    {
      if ( ! faultVarName) 
      {
        var paramValue = context.getVariable(paramName);
        print(paramName+ " : " + paramValue);
        if ((regex[0].test(paramValue))||(regex[1].test(paramValue)))
        { 
            faultVarName = paramName; 
        }
      }
    });
    */
    
    
        var paramValue;
        for(var i=0; i<array3.length; i++){
            if ((!faultVarName) && (array3[i]))
            {
                var paramName = array3[i].trim();
                if(i<hParam.length){
                    paramValue = context.getVariable("request.header." + paramName);
                     print("header"+ paramName+ " : " + paramValue);
                }
                else if(i<hParam.length + qParam.length){
                     paramValue = context.getVariable("request.queryparam." + paramName);
                     print("QP"+ paramName+ " : " + paramValue);
                }
                else{
                     paramValue = context.getVariable("request.formparam." + paramName);
                     print("FP"+ paramName+ " : " + paramValue);
                }
               
                if ((regex[0].test(paramValue))||(regex[1].test(paramValue)))
                { 
                    print("Parmeters -- "+ paramName+ " : " + paramValue);
                    faultVarName = paramName; 
                }
        }
    }
      
    
    if (faultVarName) 
    {
        context.setVariable('verify_qparams_name', faultVarName);
        print("Request param - "+ faultVarName + " rejected as unsafe.");
        threatValidCheck = "Failed";
    	threatErrorMessage = "Request rejected as unsafe.Please check";
    	context.setVariable( "flow.threatErrorMessage", threatErrorMessage );
    //	throw new Error("Request param -"+ faultVarName + " rejected as unsafe.");
    }
    else 
    {
     // context.setVariable('verify_qparams_failed', false);
        threatValidCheck = "Passed";
        /*var reqBody = context.getVariable("request.content");
        if (regex[1].test(reqBody))
        {
            print("Request body --- "+ reqBody + " rejected as unsafe.");
            threatValidCheck = "Failed";
        	threatErrorMessage = "Request rejected as unsafe.Please check";
        	context.setVariable( "flow.threatErrorMessage", threatErrorMessage );
        //	throw new Error("Request body -"+ reqBody + " rejected as unsafe.");
        }*/
    }
    //Checking the request body for threat
    
} //end of else cond of Req verb 
context.setVariable( "flow.threatValidCheck", threatValidCheck );
if (threatValidCheck === "Failed")
{
    context.setVariable("fault.name", "ThreatDetected");
    throw new Error("Request with input param- "+ faultVarName + "& request verb- "+ verb +" rejected as unsafe.Please check");
}